import React from 'react'

const CompanyRegisterForm = () => {
  return (
    <div>CompanyRegisterForm</div>
  )
}

export default CompanyRegisterForm